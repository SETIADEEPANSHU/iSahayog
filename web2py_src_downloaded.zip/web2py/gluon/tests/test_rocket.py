# TODO : I think we should continue to use pathoc (http://pathod.net/docs/pathoc) for tests but integrate the call in 
#        gluon/tests so they run automatically. No need to make our own tests.
# ref: https://groups.google.com/d/msg/web2py-developers/Cjye8_hXZk8/AXbftS3sCgAJ
